// import dotenv from "dotenv";
// dotenv.config();
// import app from "./app.js";

// app.listen(process.env.PORT, () =>
//   console.log("🚀 Backend running on port", process.env.PORT)
// );

import dotenv from "dotenv";
dotenv.config();
import app from "./app.js";

if (process.env.NODE_ENV !== "production") {
  app.listen(process.env.PORT || 3000, () => {
    console.log("🚀 Backend running locally");
  });
}
